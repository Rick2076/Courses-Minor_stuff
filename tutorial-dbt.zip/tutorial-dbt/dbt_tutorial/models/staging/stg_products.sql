WITH
    source as (
    SELECT *
    FROM {{ source('northwind_erp','products') }}
    )

SELECT* From source